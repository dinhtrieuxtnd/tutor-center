﻿namespace api_backend.DTOs.Request.Roles
{
    public class RoleUpdateRequestDto
    {
        public string Name { get; set; } = ""; 
        public string? Description { get; set; }
    }
}
