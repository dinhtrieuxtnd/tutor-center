﻿namespace api_backend.DTOs.Request.Users
{
    public class AssignRoleRequestDto
    {
        public int RoleId { get; set; }
    }
}
