﻿namespace api_backend.DTOs.Request.Classrooms
{
    public class ClassroomAssignTeacherDto
    {
        public int TeacherId { get; set; }
        public string? Note { get; set; }
    }
}
