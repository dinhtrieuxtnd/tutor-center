﻿namespace api_backend.DTOs.Request.JoinRequests
{
    public class JoinRequestUpdateStatusDto
    {
        public string Status { get; set; } = null!; // "accepted" | "denied"
        public string? Note { get; set; }
    }
}
